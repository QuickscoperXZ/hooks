#include <Windows.h>
#include <iostream>
#include <map>
#include <string>

using namespace std;

bool CheckDLLPresence(){
    HANDLE hDLLStatusHandle = GetModuleHandle(L"testdll.dll");
    if (hDLLStatusHandle == NULL){
        return false;
    }
    else return true;    
}

void cls(){
    cout << "\033[2J\033[1;1H";
}

//defines
bool bDisableSwitch = true;
int page = 1;
int runId = 0;
wchar_t pageName[18];
bool bDllStatus;

char cSelector;

//maps
map<int, string> pageToName {{1,"Process"}, {2, "Thread"}, {3, "Memory"}, {4,"File"}, {5,"Misc"}};
map<bool,string> statusToStr {{true,"LOADED"}, {false, "UNLOADED"}};

int main(int argc, char* argv[]){ 
    std::cout << "\nStanding by, awaitin library...\nPress any key after loading to continue...";
    getchar();
    cls();
    while (bDisableSwitch){
        printf("Welcome to function tester.\nCurrent page: %i:%s\n",page,pageToName[page]);
        switch (page)
        {
            case 1:
                printf("1. CreateProcess\n2. OpenProcess\n3. ExitProcess\n");
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            default:
            break;
        }
        bDllStatus = CheckDLLPresence();
        printf("Current DLL Status: %s\n\n", statusToStr[bDllStatus]);
        printf("Input number to run, input \"P\" to select page, input \"R\" to reload DLL status: ");
        
        cin >> cSelector;
    }
}